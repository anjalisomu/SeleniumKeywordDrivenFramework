// This file contains all global variables used across the automation suite
package Lib;

import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;

public class GlobalVariables {
	public static Calendar calendar = Calendar.getInstance(TimeZone.getDefault());
    //getTime() returns the current date in default time zone
    Date date = calendar.getTime();
    public static int day = calendar.get(Calendar.DATE);
    //Note: +1 the month for current month
    public static int month = calendar.get(Calendar.MONTH) + 1;
    public static int year = calendar.get(Calendar.YEAR);
    public static int dayOfWeek = calendar.get(Calendar.DAY_OF_WEEK);
    public static int dayOfMonth = calendar.get(Calendar.DAY_OF_MONTH);
    public static int dayOfYear = calendar.get(Calendar.DAY_OF_YEAR);
    public static int hour = calendar.get(Calendar.HOUR_OF_DAY);
    public static int minute = calendar.get(Calendar.MINUTE);
    public static int second = calendar.get(Calendar.SECOND);
    public static int gTotalTC,gTotalTCpass,gTotalTCfail;
    
    public static String timestamp =Integer.toString(dayOfMonth) + Integer.toString(month)+Integer.toString(year)+Integer.toString(hour)+Integer.toString(minute)+Integer.toString(second) ;
	
	
public static int IamGlobal=0;
public static int Testcase_Master_row,Business_Flow_row;
public static int Testdata_row,Lastrow;
public static int TobeExecuted = 5,BS_ID = 0,TS_ID = 1,TC_ID = 2,TestcaseName = 3;
public static String currentBSID,currentTSID,currentTCID,currenttestCaseID,currenttestCaseName;
public static String BF_BSID,BF_TS_ID,BF_TC_ID;
public static String ScreenshotPath =System.getProperty("user.dir")+"\\src\\Screenshots\\";
public static String ExcelLog =System.getProperty("user.dir")+"\\src\\Results\\ExcelLog"+timestamp+".xls";
public static String HTMLlog =System.getProperty("user.dir")+"\\src\\Results\\HTMLlogs"+timestamp+".html";
public static String ScreenshotFor = "ALL";
}
