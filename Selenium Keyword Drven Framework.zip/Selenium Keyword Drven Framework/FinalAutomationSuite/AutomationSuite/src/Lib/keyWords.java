// File contains all application specific Methods
package Lib;
import java.io.*;
import java.util.*;
import org.openqa.selenium.WebElement;

public class keyWords  {
	
	public static Properties consts;
	public static CommonFunctions CF; 
	public static Xls_Reader DataDriver;
	
	
// Initialization of object
	public keyWords()
	{
		CF = new CommonFunctions();
	}

// Keyword to launch the application	
	public int LaunchURL() throws IOException, InterruptedException 
	{
		consts = new Properties();
		WebElement obj;
		 FileInputStream fs = new FileInputStream(System.getProperty("user.dir")+"\\src\\Config\\Constant.properties");
		 consts.load(fs);
		 //System.out.println("URL "+consts.getProperty("URL"));
		 CF.openBrowser();
		 CF.Navigate(consts.getProperty("URL"));
		 Thread.sleep(5000);
		 obj=CF.getObject("xpath", "GoogleSearch");
		 if (obj!=null){
			 //System.out.println("GoogleSearch Exist ");
			 return 1;
		 }
		 else{
			 //System.out.println("GoogleSearch not Exist ");
			 return 0;
		 }
	}
// Keyword to search a text in Google	
	public int SearchGoogle() throws IOException, InterruptedException 
	{
		WebElement obj;
		int i;
		obj=CF.getObject("xpath", "GoogleSearch");
		if (obj!=null){
			i= CF.enterText(obj,GetKeywordFieldData("SearchText"));
			obj=CF.getObject("xpath", "GoogleSrchBtn");
			if (obj!=null){
				i= CF.click(obj);
				obj=CF.getObject("xpath", "SearchResult");
				if (obj!=null){
					//System.out.println("Search Exist "+str);
					return i;}
				else{
					//System.out.println("SearchResult not Exist ");
					return 0;
				 }
				}
			else{
				//System.out.println("GoogleSrchBtn not Exist ");
				return 0;
			}
		}
		else{
			//System.out.println("GoogleSearch not Exist ");
			return 0;
		}
	}

// Keyword to change Google language	
	public int ChangeLanguage() throws IOException, InterruptedException
	{
		WebElement obj;
		int i;
		obj=CF.getObject("xpath",GetKeywordFieldData("Language"));
		if (obj!=null){
			i=CF.click(obj);
			Thread.sleep(5000);
			obj=CF.getObject("xpath", "English");
			i=CF.click(obj);
			return i;
		}
		else{
			//System.out.println("Language not Exist ");
			return 0;
		}
	}

// Keyword to close all opened browsers	
	public int CloseallBrowsers() throws IOException, InterruptedException 
	{
		CF.closeBrowser();
		 return 1;
	}
	
// Method to get Test data for a particular  field	
	public String GetKeywordFieldData(String FieldName){
		String FieldValue ="";
		String TD_BSID,TD_TSID,TD_TCID;
		DataDriver =  new Xls_Reader(System.getProperty("user.dir")+"\\src\\datatables\\Test_Data.xls");
		//System.out.println(" FieldName :"+FieldName);
		int i = DataDriver.getColumnNo("TestData", FieldName);
		//System.out.println(FieldName+" Field  is at :"+i);
		//System.out.println(" currentBSID :"+GlobalVariables.currentBSID);
		//System.out.println(" currentTSID :"+GlobalVariables.currentTSID);
		//System.out.println(" TD_TCID :"+GlobalVariables.currentTCID);
		for (GlobalVariables.Testdata_row =2;GlobalVariables.Testdata_row<= DataDriver.getRowCount("TestData");GlobalVariables.Testdata_row++){
			TD_BSID=DataDriver.getColumnValue("TestData", GlobalVariables.BS_ID, GlobalVariables.Testdata_row);
			TD_TSID=DataDriver.getColumnValue("TestData", GlobalVariables.TS_ID, GlobalVariables.Testdata_row);
			TD_TCID=DataDriver.getColumnValue("TestData", GlobalVariables.TC_ID, GlobalVariables.Testdata_row);
			//System.out.println(" TD_BSID :"+TD_BSID);
			//System.out.println(" TD_TSID :"+TD_TSID);
			//System.out.println(" TD_TCID :"+TD_TCID);
			if (TD_BSID.equals(GlobalVariables.currentBSID) && TD_TSID.equals(GlobalVariables.currentTSID) && TD_TCID.equals(GlobalVariables.currentTCID)){
				 FieldValue =DataDriver.getColumnValue("TestData", i, GlobalVariables.Testdata_row);
				  break;			
				}
			}
		return FieldValue;
	}

}
